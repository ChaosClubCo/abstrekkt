# Loxihart Control API

Server-authoritative API for the Loxihart Pilot Console, backed by Canonical Pilot Kernel v0.3.0.

## Trust boundary

Pre-verification operations are typed append-only control events with optimistic `expectedVersion` checks and a SHA-256 event chain. Final verification is never computed by the browser: `verification.commit` assembles the pilot evaluation from server-owned approvals/evidence and commits it through Canonical Pilot Kernel v0.3.0, producing an Ed25519-signed ChangeReceipt.

## Operations

- `GET /v1/pilots/:pilotId`
- `POST /v1/pilots/:pilotId/workflow/approve`
- `POST /v1/pilots/:pilotId/sop/approve`
- `POST /v1/pilots/:pilotId/baseline/lock`
- `POST /v1/pilots/:pilotId/change/approve`
- `POST /v1/pilots/:pilotId/evidence`
- `POST /v1/pilots/:pilotId/verification/commit`
- `GET /v1/pilots/:pilotId/receipts/:receiptId`
- `POST /v1/pilots/:pilotId/receipts/:receiptId/verify`
- `GET /v1/pilots/:pilotId/stream/head`
- `GET /v1/pilots/:pilotId/stream`

## Demo authentication

The currently deployable pilot uses only fictional Lakeview HVAC data. Requests require:provaX-Loxihart-Demo-Token`rovaX-Loxihart-Organization`rovaX-Loxihart-Actor`

The browser cannot override actor/organization via JSON body; the HTTP layer replaces those fields from authenticated headers.

## Required environmentprovaLOXIHART_SIGNING_KEY_ID`rovaLOXIHART_SIGNING_PRIVATE_KEY_B64` — PKCS#8 PEM base64rovaLOXIHART_SIGNING_PUBLIC_KEY_B64` — SPKI PEM base64rovaLOXIHART_DEMO_TOKEN`rovaLOXIHART_ALLOWED_ORIGINS`rovaLOXIHART_DATA_DIR` optional; default `/tmp/loxihart-control-api`
- `PORT` optional; default `8080`

## Production note

The live demo intentionally uses the kernel's file-backed append-only mutation store and a file-backed control event store so it can be deployed without exposing a database password. This is server-authoritative and tamper-evident, but not a multi-node production persistence topology. Before a real customer pilot, replace both stores with PostgreSQL-backed implementations and gateway identity/JWT auth.

## Verification

```bash
npm test
```
