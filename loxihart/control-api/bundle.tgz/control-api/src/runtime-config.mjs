import { generateKeyPairSync } from 'node:crypto';
import { mkdir, readFile, writeFile, chmod } from 'node:fs/promises';
import { join } from 'node:path';

const DEFAULT_ORIGIN = 'https://loxihart-pilot-console.onhercules.app';
const DEFAULT_TOKEN = 'loxihart-public-demo-v1';

async function readIfExists(path) {
  try { return await readFile(path, 'utf8'); }
  catch (error) { if (error?.code === 'ENOENT') return null; throw error; }
}

async function loadOrCreateSigning(dataDir) {
  const signingDir = join(dataDir, 'signing');
  await mkdir(signingDir, { recursive: true });
  const privatePath = join(signingDir, 'ed25519-private.pem');
  const publicPath = join(signingDir, 'ed25519-public.pem');
  const keyIdPath = join(signingDir, 'key-id.txt');

  const [privateExisting, publicExisting, keyIdExisting] = await Promise.all([
    readIfExists(privatePath), readIfExists(publicPath), readIfExists(keyIdPath),
  ]);
  if (privateExisting && publicExisting && keyIdExisting) {
    return { privateKey: privateExisting, publicKey: publicExisting, keyId: keyIdExisting.trim() };
  }
  if (privateExisting || publicExisting || keyIdExisting) {
    throw new Error('Incomplete persisted signing material; refusing to replace it silently.');
  }

  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  const privatePem = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
  const publicPem = publicKey.export({ type: 'spki', format: 'pem' }).toString();
  const keyId = `demo-ed25519-${Date.now().toString(36)}`;
  await writeFile(privatePath, privatePem, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  await writeFile(publicPath, publicPem, { encoding: 'utf8', mode: 0o644, flag: 'wx' });
  await writeFile(keyIdPath, `${keyId}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  await chmod(privatePath, 0o600);
  return { privateKey: privatePem, publicKey: publicPem, keyId };
}

export async function loadRuntimeConfig(env = process.env) {
  const dataDir = env.LOXIHART_DATA_DIR?.trim() || '/tmp/loxihart-control-api';
  const port = Number(env.PORT ?? 8080);
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be a valid TCP port.');
  const allowedOrigins = (env.LOXIHART_ALLOWED_ORIGINS?.trim() || DEFAULT_ORIGIN)
    .split(',').map((x) => x.trim()).filter(Boolean);
  const demoToken = env.LOXIHART_DEMO_TOKEN?.trim() || DEFAULT_TOKEN;

  let signing;
  if (env.LOXIHART_SIGNING_PRIVATE_KEY_B64 && env.LOXIHART_SIGNING_PUBLIC_KEY_B64 && env.LOXIHART_SIGNING_KEY_ID) {
    signing = {
      keyId: env.LOXIHART_SIGNING_KEY_ID,
      privateKey: Buffer.from(env.LOXIHART_SIGNING_PRIVATE_KEY_B64, 'base64').toString('utf8'),
      publicKey: Buffer.from(env.LOXIHART_SIGNING_PUBLIC_KEY_B64, 'base64').toString('utf8'),
    };
  } else {
    signing = await loadOrCreateSigning(dataDir);
  }
  return Object.freeze({ port, dataDir, allowedOrigins, demoToken, signing });
}
