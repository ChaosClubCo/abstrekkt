import { Buffer } from 'node:buffer';
import {
  Ed25519ReceiptSigner,
  FileAppendOnlyMutationStore,
} from '@loxihart/canonical-pilot-kernel';
import {
  PilotControlService,
  createLakeviewSeedPilot,
} from './control-domain.mjs';
import { FilePilotControlStore } from './file-control-store.mjs';
import { VerificationService } from './verification-service.mjs';
import { createControlHttpServer } from './http-api.mjs';

function required(name) {
  const value = process.env[name];
  if (!value?.trim()) throw new Error(`${name} is required.`);
  return value;
}

function decodePem(name) {
  return Buffer.from(required(name), 'base64').toString('utf8');
}

const port = Number(process.env.PORT ?? 8080);
if (!Number.isSafeInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be a valid TCP port.');

const dataDir = process.env.LOXIHART_DATA_DIR?.trim() || '/tmp/loxihart-control-api';
const keyId = required('LOXIHART_SIGNING_KEY_ID');
const privateKey = decodePem('LOXIHART_SIGNING_PRIVATE_KEY_B64');
const publicKey = decodePem('LOXIHART_SIGNING_PUBLIC_KEY_B64');
const demoToken = required('LOXIHART_DEMO_TOKEN');
const allowedOrigins = required('LOXIHART_ALLOWED_ORIGINS').split(',').map((x) => x.trim()).filter(Boolean);

const seed = createLakeviewSeedPilot({ includeDemoEvidence: true });
const controlStore = new FilePilotControlStore(`${dataDir}/control`, [seed]);
const kernelStore = new FileAppendOnlyMutationStore(`${dataDir}/kernel`);
const control = new PilotControlService(controlStore);
const signer = new Ed25519ReceiptSigner(keyId, privateKey);
const verification = new VerificationService({
  controlStore,
  kernelStore,
  signer,
  resolvePublicKey: (candidate) => candidate === keyId ? publicKey : undefined,
});

const server = createControlHttpServer({
  control,
  verification,
  allowedOrigins,
  auth: { mode: 'demo', token: demoToken },
});

server.listen(port, '0.0.0.0', () => {
  console.log(JSON.stringify({
    level: 'info',
    event: 'loxihart_control_api_started',
    port,
    persistence: 'file-demo',
    dataDir,
    allowedOrigins,
    signingKeyId: keyId,
  }));
});

const shutdown = (signal) => {
  console.log(JSON.stringify({ level: 'info', event: 'shutdown', signal }));
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
