import { mkdir, open, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { canonicalHash } from '@loxihart/canonical-pilot-kernel';
import {
  ControlError,
  assertEventIntegrity,
  buildControlEvent,
  reconstructPilotState,
} from './control-domain.mjs';

function errorCode(error) {
  return error && typeof error === 'object' && 'code' in error ? String(error.code) : undefined;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export class FilePilotControlStore {
  constructor(rootDirectory, seeds = []) {
    if (!rootDirectory?.trim()) throw new Error('rootDirectory must not be empty.');
    this.rootDirectory = rootDirectory.replace(/\/+$/, '');
    this.seeds = new Map(seeds.map((seed) => [seed.pilotId, structuredClone(seed)]));
  }

  key(pilotId) { return canonicalHash(pilotId); }
  eventsFile(pilotId) { return `${this.rootDirectory}/${this.key(pilotId)}.events.json`; }
  lockFile(pilotId) { return `${this.rootDirectory}/${this.key(pilotId)}.lock`; }

  seed(seed) {
    if (!this.seeds.has(seed.pilotId)) this.seeds.set(seed.pilotId, structuredClone(seed));
  }

  requireSeed(pilotId) {
    const seed = this.seeds.get(pilotId);
    if (!seed) throw new ControlError('NOT_FOUND', `Pilot ${pilotId} was not found.`);
    return seed;
  }

  async loadEvents(pilotId) {
    this.requireSeed(pilotId);
    try {
      const raw = await readFile(this.eventsFile(pilotId), 'utf8');
      const events = JSON.parse(raw);
      if (!Array.isArray(events)) throw new Error('event file root must be an array');
      assertEventIntegrity(events);
      return events;
    } catch (error) {
      if (errorCode(error) === 'ENOENT') return [];
      if (error instanceof ControlError) throw error;
      throw new ControlError('INTEGRITY_ERROR', `Failed to read control events for ${pilotId}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async readPilot(pilotId) {
    const seed = this.requireSeed(pilotId);
    const events = await this.loadEvents(pilotId);
    return reconstructPilotState(seed, events);
  }

  async readEvents(pilotId) {
    const events = await this.loadEvents(pilotId);
    return Object.freeze(structuredClone(events));
  }

  async acquire(pilotId) {
    await mkdir(this.rootDirectory, { recursive: true });
    const lockPath = this.lockFile(pilotId);
    const deadline = Date.now() + 5000;
    while (true) {
      try {
        const handle = await open(lockPath, 'wx', 0o600);
        return async () => {
          try { await handle.close(); } finally { await unlink(lockPath).catch(() => {}); }
        };
      } catch (error) {
        if (errorCode(error) !== 'EEXIST') throw error;
        if (Date.now() >= deadline) throw new ControlError('INTEGRITY_ERROR', `Timed out acquiring control lock for ${pilotId}.`);
        await sleep(8);
      }
    }
  }

  async persistEvents(pilotId, events) {
    await mkdir(this.rootDirectory, { recursive: true });
    const destination = this.eventsFile(pilotId);
    const temp = `${destination}.${process.pid}.${randomUUID()}.tmp`;
    await writeFile(temp, `${JSON.stringify(events)}\n`, { encoding: 'utf8', mode: 0o600 });
    await rename(temp, destination);
  }

  async appendAtomic(pilotId, command) {
    const seed = this.requireSeed(pilotId);
    const release = await this.acquire(pilotId);
    try {
      const events = await this.loadEvents(pilotId);
      if (events.some((event) => event.mutationId === command.mutationId)) {
        throw new ControlError('DUPLICATE_MUTATION', `Mutation ${command.mutationId} already exists for ${pilotId}.`);
      }
      const state = reconstructPilotState(seed, events);
      if (command.expectedVersion !== state.version) {
        throw new ControlError('STALE_VERSION', `expectedVersion ${command.expectedVersion} does not match current version ${state.version}.`, { currentVersion: state.version });
      }
      const event = buildControlEvent(seed, state, command);
      const nextState = reconstructPilotState(seed, [...events, event]);
      await this.persistEvents(pilotId, [...events, event]);
      return { state: nextState, event };
    } finally {
      await release();
    }
  }
}
